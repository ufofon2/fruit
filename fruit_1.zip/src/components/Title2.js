import React from "react";

const Title2 = () => {
  let csst1 = {
    marginTop: "70px",
  };
  return (
    <>
      <h3 style={csst1}>채소.야채 TOP</h3>
      <p>청정지역, 황토밭에서 자란 건강식품</p>
    </>
  );
};

export default Title2;
